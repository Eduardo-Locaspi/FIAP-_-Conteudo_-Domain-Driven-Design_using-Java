import java.util.HashMap;
import java.util.Map;
import java.util.Map;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //key -> integer
        //values-> string

        Map<Integer,String> mapa = new HashMap<>();
        mapa.put(1,"Henrique");
        mapa.put(2,"Vizinho");
        mapa.put(3,"Tigre");
        mapa.put(50,"Leão");

        System.out.println(mapa);

        mapa.put(1,"Trocou"); // alteração de valores ja existentes
        System.out.println(mapa);

        System.out.println(mapa.get(2)); // retorno especifico (indice 2)

        System.out.println(mapa.get(2).equals("abc"));


        System.out.println("=================================");
        //Hash map com objeto atribuido

        Map<Integer,Aluno> mapa2 = new HashMap<>();
        mapa2.put(45,new Aluno("João", "1234567812"));
        System.out.println(mapa2.get(45).getNome());
        System.out.println(mapa2.get(45).getCpf());

        mapa2.put(1,new Aluno("Jonathan", "1234567812"));



        for (Map.Entry<Integer,Aluno> iterador : mapa2.entrySet()){
            int chave = iterador.getKey();
            Aluno a = iterador.getValue();
            System.out.println(chave+"| Nome: "+a.getNome()+" | CPF:"+a.getCpf());
        }

    }
}
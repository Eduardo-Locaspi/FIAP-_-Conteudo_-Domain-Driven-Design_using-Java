//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Calculadora c = new Calculadora();
        int soma = c.soma(1,2);
        int subtracao = c.sub(1,2);
        double divisao = c.div(1,2);

        for (int i=0; i<=10; i++){
            System.out.println(i);
        }
        //boolean x = true;
        //int valor = 50;

//        while (x==true){
//            if (valor ==50){
//                System.out.println("WHile feito");
//                break;
//            }
//            valor++;
//        }
//
//        do{
//            valor++;
//
//            if (valor==50){
//                System.out.println("Do While feito");
//            }
//
//        }while(x ==true);
//
//
////        for (int valor = 0; valor<=50; valor++){
////
////        }
//

    }
}
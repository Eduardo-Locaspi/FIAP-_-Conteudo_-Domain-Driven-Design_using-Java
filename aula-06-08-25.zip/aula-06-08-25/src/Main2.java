
import java.util.Scanner;

public class Main2 {
    public static void main(String[] args) {
        Pessoa[] pessoas = new Pessoa[3];

        Scanner sc = new Scanner(System.in);
        for (int i =0;i<pessoas.length;i++){

            Pessoa p = new Pessoa() ;

            System.out.print("Digite o seu id: ") ;
            p.setId(Integer.parseInt(sc.nextLine())) ; // Configura a entrada de dados(input) para o id

            System.out.print("Seu Nome: ") ;
            p.setNome(sc.nextLine()) ;

            System.out.print("Endereco: ") ;
            p.setEndereco(sc.nextLine()) ;

            pessoas[i]= p ;
        }

        for (int i=0;i<pessoas.length;i++){
            System.out.println("Convidado "+i);
            pessoas[i].dados();
            System.out.println("============================");
        }
    }
}
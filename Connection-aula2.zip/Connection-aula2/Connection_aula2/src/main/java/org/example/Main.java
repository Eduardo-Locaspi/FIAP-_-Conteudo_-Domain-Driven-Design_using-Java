package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;


public class Main {
    public static void main(String[] args) {
        ExemploStatement es = new ExemploStatement();
        es.inserirDado();

        List<ABC> l = es.buscarDadosNoBD();

        for (ABC iterador:l) {
            System.out.println(iterador.getId());
            System.out.println(iterador.getNome());
            System.out.println(iterador.getIdade());
        }


//        String server = "oracle.fiap.com.br";
//        String porta = "1521";
//        String user ="rm561713";
//        String passwd ="290107";
//        String sid ="ORCL";
//        String url ="jdbc:oracle:thin:@"+server+":"+porta+":"+sid;
//
//        try {
//            Connection con = DriverManager.getConnection(url,user,passwd);
//            System.out.println("Conectado");
//
//            String comandoSql = "CREATE TABLE TDSPI(id number, nome)";
//
//            Statement st = con.createStatement();
//
//        } catch (SQLException e) {
//            System.out.println("Conexão não encontrada");
//        }


    }
}
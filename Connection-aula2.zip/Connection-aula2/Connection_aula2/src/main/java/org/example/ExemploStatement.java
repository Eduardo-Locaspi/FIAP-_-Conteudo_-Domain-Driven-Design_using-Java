package org.example;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ExemploStatement {

    String server = "oracle.fiap.com.br";
    String porta = "1521";
    String user ="rm561713";
    String passwd ="290107";
    String sid ="ORCL";
    String url ="jdbc:oracle:thin:@"+server+":"+porta+":"+sid;


    public void inserirDado() {
        try {
            Connection con = DriverManager.getConnection(url, user, passwd);
            System.out.println("Conectado");

            String comandoSQL = "INSERT INTO abc VALUES(1,'Jonathan',29)";
            Statement st = con.createStatement();

            int valor = st.executeUpdate(comandoSQL);
            if (valor > 0) {
                System.out.println("Inseriu");
            } else {
                System.out.println("Não inseriu");
            }

        } catch (SQLException e) {
            System.out.println("Conexão não Encontrada");
            System.out.println(e.getMessage());
        }
    }


    public List<ABC> buscarDadosNoBD(){
        try {
            List<ABC> l= new ArrayList<>();
            Connection conn = DriverManager.getConnection(url,user,passwd);

            String sql = "SELECT * FROM abc";


            ResultSet rs; //rs é uma lista
            Statement st = conn.createStatement();

            rs= st.executeQuery(sql);

            while(rs.next()){
                ABC abc = new ABC(rs.getInt(1),rs.getString(2),rs.getInt(3));
//                System.out.println(rs.getInt(1));
//                System.out.println(rs.getString(2));
//                System.out.println(rs.getInt(3));
                l.add(abc);
            }

            rs.close();
            st.close();
            conn.close();
            return l;
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }

    }

    public void preparado(int id){
        try {
            Connection c = DriverManager.getConnection(url,user,passwd);

            String sql = "SELECT * FROM abc where id=?";
            PreparedStatement pst = c.prepareStatement(sql);

            pst.setInt(1,id);

            ResultSet rs= pst.executeQuery();

            while(rs.next()) {
                System.out.println(rs.getInt(1));
                System.out.println(rs.getString(2));
                System.out.println(rs.getInt(3));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

package Cliente;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main_Cliente {
    public static void main(String[] args) {
        List<Cliente> lista_clientes= new ArrayList<>();

        lista_clientes.add(new Cliente("Eduardo","1234567812"));
        lista_clientes.add(new Cliente("Maria","98765432198"));

        //Ordenação de listas de objetos (usa -se COMPARABLE)
        //Collections.sort(lista_clientes);

        for  (int i =0; i < lista_clientes.size(); i++){
            System.out.println(lista_clientes.get(i));

        }

    }
}

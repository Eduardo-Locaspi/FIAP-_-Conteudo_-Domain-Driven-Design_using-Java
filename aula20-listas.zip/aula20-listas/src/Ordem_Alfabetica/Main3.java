package Ordem_Alfabetica;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main3 {
    public static void main(String[] args){
        //Criação de uam lista de nomes
        List<String> lista_nomes = new ArrayList<>();

        //o usuario digita os nomes
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < 5; i++) {
            System.out.print(i+1+"° Nome:");
            lista_nomes.add(sc.nextLine());
        }

        // a ordem digitada
        System.out.println("\nOrdem Digitada: ");
        for (int i = 0; i < lista_nomes.size(); i++) {
            System.out.println(lista_nomes.get(i));
        }

        System.out.println("\nLista Ordenada");
        Collections.sort(lista_nomes);
        System.out.println(lista_nomes);

        System.out.println("\nNomes com a letra A: ");
        for(String _nome: lista_nomes){

            if (_nome.charAt(0) == 'a' || _nome.charAt(0) =='A'){
                System.out.println(_nome);
            }
        }

        System.out.print("\nQual nome você gostaria de conferir: ");
        String nome_escolhido = sc.nextLine();
        for (String _nome : lista_nomes) {

            if (_nome.equals(nome_escolhido) ){
                System.out.println("\nO nome "+_nome+" está na lista");
            }
        }



    }
}

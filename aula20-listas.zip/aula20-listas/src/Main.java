import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //ArrayList -> redimensionável conforme a demanda

        //LinkedList -> estudar

        List<Integer> lista_numeros= new ArrayList<>(); // Criação de uma lista (ArrayList)

        lista_numeros.add(2);
        lista_numeros.add(1);
        lista_numeros.add(36);
        lista_numeros.add(10);
        lista_numeros.add(48);

        System.out.println(lista_numeros);

        System.out.println(lista_numeros.get(2)); //output :36

        System.out.println(lista_numeros.size()); // Retorna o tamanho da lista

        System.out.println("PERCORRENDO LISTAS");
        System.out.println("USANDO O FOR");
        //Esse FOR percorre toda a lista
        for  (int i =0; i < lista_numeros.size(); i++){
            System.out.println(lista_numeros.get(i));

            //Verificador
            if (lista_numeros.get(i) ==3){
                System.out.println("É 3");
            }
        }

        //Dessa 2ª forma, o iterador não pode ser usado, pois o iterador recebe o conteudodo indice da lista
        for(Integer iterador:lista_numeros){
            System.out.println(iterador);

            if (iterador ==3){
                System.out.println("É 3");
            }
        }

        Collections.sort(lista_numeros);
        System.out.println(lista_numeros); //LIsta ordenada de numeros

    }
}